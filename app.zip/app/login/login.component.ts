import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
Login:any;
  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
    this.Login = this.fb.group({
      name:new FormControl('',),
      email:new FormControl('',),
      password:new FormControl('',),
      checkbox:new FormControl('',),
    })
  }

}
