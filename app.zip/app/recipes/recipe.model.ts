import { ingredients } from "../shared/ingredient.model";

export class Recipe{
    public name:string;
    public description:string;
    public imagepath:string;
    public ingredients:ingredients[]
constructor(name:string,description:string,imagepath:string,ingredients:ingredients[]){
    this.name = name;
    this.description = description;
    this.imagepath = imagepath;
    this.ingredients = ingredients; 
}

}