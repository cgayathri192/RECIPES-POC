import { Injectable } from "@angular/core";
import { ingredients } from "../shared/ingredient.model";
import { ShoppingListService } from "../shopping-list/shopping-list.service";
import { Recipe } from "./recipe.model";
import { Subject } from "rxjs";

@Injectable()

export class RecipeService {
    recipesChanged = new Subject<Recipe[]>()
    
    private recipes: Recipe[] =
        [
            new Recipe(
                'Tasty Schnitzel',
                'A super-tasty Schnitzel - just awesome!',
                'https://upload.wikimedia.org/wikipedia/commons/7/72/Schnitzel.JPG',
                [new ingredients('Meat', 1),
                new ingredients('French Fries', 20)]),
            new Recipe(
                'Big Fat Burger',
                'What else you need to say?',
                'https://th.bing.com/th?id=OIP.l0lBNfhyHKRkAdGygzrEOgHaHX&w=250&h=249&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2',
                [new ingredients('Buns', 2),
                new ingredients('Meat', 1)])
        ];
    constructor(private slService: ShoppingListService) { }
    getrecipes() {
        return this.recipes.slice()
    }
    getRecipe(index: number) {
        return this.recipes[index]
    }
    addIngredientsToShoppingList(ingredient: ingredients[]) {
        this.slService.addIngredients(ingredient)

    }
    addRecipe(recipe:Recipe){
         this.recipes.push(recipe);
         this.recipesChanged.next(this.recipes.slice())
    }
    updateRecipe(index:number,newRecipe:Recipe){
        this.recipes[index] = newRecipe;
        this.recipesChanged.next(this.recipes.slice())
    }
    deleteRecipe(index:number){
        this.recipes.splice(index,1);
        this.recipesChanged.next(this.recipes.slice())

    }
}